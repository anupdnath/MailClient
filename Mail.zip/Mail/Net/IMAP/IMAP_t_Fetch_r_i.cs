﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.IMAP
{
    /// <summary>
    /// This class is base class for IMAP FETCH response data-items. Defined in RFC 3501 7.4.2.
    /// </summary>
    public abstract class IMAP_t_Fetch_r_i
    {
    }
}
