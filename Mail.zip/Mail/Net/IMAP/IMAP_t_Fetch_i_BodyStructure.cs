﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.IMAP
{
    /// <summary>
    /// This class represents FETCH request BODYSTRUCTURE argument(data-item). Defined in RFC 3501.
    /// </summary>
    class IMAP_t_Fetch_i_BodyStructure : IMAP_t_Fetch_i
    {
    }
}
