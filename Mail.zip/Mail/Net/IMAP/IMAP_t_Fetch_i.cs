﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.IMAP
{
    /// <summary>
    /// This class is base class for IMAP FETCH request arguments(data-items). For more info see RFC 3501. 6.4.5.
    /// </summary>
    public abstract class IMAP_t_Fetch_i
    {
    }
}
