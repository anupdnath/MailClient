﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.IMAP
{
    /// <summary>
    /// This class represents FETCH request BODY argument(data-item). Defined in RFC 3501.
    /// </summary>
    class IMAP_t_Fetch_i_BodyS : IMAP_t_Fetch_i
    {
    }
}
