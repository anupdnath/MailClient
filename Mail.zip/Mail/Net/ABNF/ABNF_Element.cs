﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.ABNF
{
    /// <summary>
    /// Thsi class is base class for any ABNF element.
    /// </summary>
    public abstract class ABNF_Element
    {
    }
}
