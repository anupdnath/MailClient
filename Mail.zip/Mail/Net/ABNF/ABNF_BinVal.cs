﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.ABNF
{
    /// <summary>
    /// This class represent ABNF "bin-val". Defined in RFC 5234 4.
    /// </summary>
    public class ABNF_BinVal
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public ABNF_BinVal()
        {
        }


        #region Properties implementation

        #endregion
    }
}
