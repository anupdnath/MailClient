﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.SIP.Stack
{
    /// <summary>
    /// This class is base class for SIP dialog usages. For more info see RFC 5070.
    /// </summary>
    public abstract class SIP_Dialog_Usage
    {
    }
}
