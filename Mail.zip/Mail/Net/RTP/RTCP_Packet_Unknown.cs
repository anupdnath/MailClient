﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.RTP
{
    /// <summary>
    /// This class represents unknown RTCP packet.
    /// </summary>
    public class RTCP_Packet_Unknown
    {
        // private int    m_Type    = 0:
        // private byte[] m_pPacket = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public RTCP_Packet_Unknown()
        {
        }

        // TODO:

        #region Properties Implementation

        #endregion

    }
}
