﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using D.Net.EmailInterfaces;

namespace D.Net.EmailClient
{
    class Test
    {
        static void Readmail()
        {
            IEmailClient ImapClient = EmailClientFactory.GetClient(EmailClientEnum.IMAP);
            ImapClient.Connect("imap.gmail.com", "mymail@gmail.com", "password", 993, true);
            ImapClient.SetCurrentFolder("INBOX");
            // I assume that 5 is the last "ID" readed by my client. 
            // If I want to read all messages i use "ImapClient.LoadMessages();"
            ImapClient.LoadRecentMessages(5);
            // To read all my messages loaded:
            for (int i = 0; i < ImapClient.Messages.Count; i++)
            {
                IEmail msm = (IEmail)ImapClient.Messages[i];
                // Load all infos include attachments
                msm.LoadInfos();
                Console.Write(msm.Date.ToString() + " - " + msm.From[0] + " - " +
                                  msm.Subject + " - " + msm.Attachments.Count);
            }
        }

        static void Main()
        {
            Readmail();
        }
    }
}
